"""
labrad.test

test cases for the python labrad module.
"""
