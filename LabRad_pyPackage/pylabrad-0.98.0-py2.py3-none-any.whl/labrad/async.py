# provides a convenient namespace for asynchronous support functions using twisted

from labrad.wrappers import connectAsync, runAsync
